//
//  BorderedButton.swift
//  GetPony PriceEstimator
//
//  Created by Onesimos on 12/20/18.
//  Copyright © 2018 Onesimos. All rights reserved.
//

import UIKit

class BorderedButton: UIButton {

    override func awakeFromNib() {
        super.awakeFromNib()
        layer.borderWidth = 1.5
        layer.borderColor = UIColor.white.cgColor
        layer.cornerRadius = 7.0
        layer.backgroundColor = #colorLiteral(red: 0.8409366904, green: 0.8409366904, blue: 0.8409366904, alpha: 0.5)
        //layer.border.color = UIColor.white.cgColor
    }

}
