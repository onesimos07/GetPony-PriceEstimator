//
//  ViewController.swift
//  GetPony PriceEstimator
//
//  Created by Onesimos on 12/20/18.
//  Copyright © 2018 Onesimos. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var startPointtxt: UITextField!
    @IBOutlet weak var endPointtxt: UITextField!
    @IBOutlet weak var estimatedPricelbl: UILabel!

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }


    
    
    @IBAction func getPricebtn(_ sender: Any) {
    }
    
}

